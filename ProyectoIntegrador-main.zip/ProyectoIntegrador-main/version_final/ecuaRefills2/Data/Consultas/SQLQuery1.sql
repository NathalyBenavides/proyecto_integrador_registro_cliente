﻿SELECT * FROM dbo.Provincia;
SELECT * FROM dbo.Ciudad;

